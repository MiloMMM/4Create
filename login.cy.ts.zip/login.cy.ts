describe('login test', () => {

  beforeEach(() => {
    cy.visit('https://petstore.octoperf.com/actions/Catalog.action')

  })


  // Positive test case
  it.skip('postive test case for login', () => {

    cy.get('[class="btn btn-primary"]', { timeout: 10000 }).click();
    cy.contains("Sign in", { matchCase: false }).click();    // i used cy.contain because cypress could not find specific class/id
    cy.get('#login > .form-field > #id_identity').type("777"); 
    cy.get('#login > .btn').click();
    cy.get('[class="input-labeled-password-field"]').type("777777777");
    cy.get('#password-login > .btn').click();
    cy.get('[class="btn close-btn"]').first().click();
    cy.contains("Welcome 123!");
  })
